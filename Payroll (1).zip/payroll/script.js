function calculatePayroll() {
  const employeeName = document.getElementById("employeeName").value;
  const hoursWorked = parseFloat(document.getElementById("hoursWorked").value);
  const hourlyRate = parseFloat(document.getElementById("hourlyRate").value);
  const taxRate = parseFloat(document.getElementById("taxRate").value);

  // Calculate Gross Pay
  const grossPay = hoursWorked * hourlyRate;

  // Calculate Deductions
  const taxDeduction = (taxRate / 100) * grossPay;

  // Calculate Net Pay
  const netPay = grossPay - taxDeduction;

  // Display Results
  document.getElementById("result").innerHTML = `
        <h3>Payroll Summary for ${employeeName}</h3>
        <p>Gross Pay: $${grossPay.toFixed(2)}</p>
        <p>Tax Deduction (${taxRate}%): $${taxDeduction.toFixed(2)}</p>
        <p>Net Pay: $${netPay.toFixed(2)}</p>
    `;
}